format long
v1 = importdata('v1.tiger.txt');
v2 = importdata('v2.tiger.txt'); 

v1avg = mean(v1)
v2avg = mean(v2)